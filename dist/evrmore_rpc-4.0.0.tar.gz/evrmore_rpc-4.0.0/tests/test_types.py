from evrmore_rpc.client import EvrmoreClient
from evrmore_rpc.models.blockchain import BlockchainInfo
def test_blockchain_info():
    client = EvrmoreClient()
    blockchain_info = client.getblockchaininfo()
    blockchain_info.
    


test_blockchain_info()